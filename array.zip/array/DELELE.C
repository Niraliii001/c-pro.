//delete array element
#include<stdio.h>
#include<conio.h>

void main()
{
	int a[10], n, pos;
	clrscr();
	printf("\nEnter array element to stored: ");
	scanf("%d",&n);
	for(int i=0;i<=n-1;i++)
	{
		printf("\nEnter element value: ");
		scanf("%d",&a[i]);
	}
	printf("\nEnter postion to delete element:");
	scanf("%d",&pos);
	if(pos>n)
	{
		printf("\nDeletion is not possible");
	}
	else
	{
		for(i=pos-1;i<=n-1;i++)
			a[i]=a[i+1];
		printf("\nResulted array\n");
		for(i=0;i<n-1;i++)
			printf("\n%d",a[i]);
	}
	getch();
}