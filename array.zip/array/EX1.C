#include<stdio.h>
#include<conio.h>

int main()
{
	int a[5], b[10], n, i;

	printf("\nEnter array elements to store: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nEnter array value a[%d]: ",i);
		scanf("%d",&a[i]);
	}

	for(i=0;i<n;i++)
	{
		b[i]=a[i];
		printf("\nAfter copy into b[%d]:%d",i,b[i]);
	}
	return 0;
}