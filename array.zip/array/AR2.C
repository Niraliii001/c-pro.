#include<stdio.h>
#include<conio.h>

void main()
{
	int a[10], a1[10], n,i;
	clrscr();
	printf("\nEnter any number to be stored in array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("\nFirst array element: %d",a[i]);
	}
	printf("\n\nSecond array elements with reverse....\n");
	for(i=0;i<n;i++)
	{
		a1[i]=a[i];
	}
	for(i=n-1;i>=0;i--)
	{
		printf("\nafter copy element in array with reverse ...%d",a1[i]);
	}
	getch();
}