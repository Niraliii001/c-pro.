//find two max numbers
#include<stdio.h>
#include<conio.h>
void main()
{
	int a[10], n, larg, seclarg,i;
	clrscr();
	printf("\nEnter array size that you want to store: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nEnter array value: ");
		scanf("%d",&a[i]);
	}
	larg=seclarg=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>larg)
		{
			seclarg=larg;
			larg=a[i];
		}
	}
	printf("\nnFirst large value is %d",larg);
	printf("\nsec large value is %d",seclarg);
	getch();
}