#include <stdio.h>
#include <conio.h>

void findLargestTwoNumbers(int arr[], int n, int *largest, int *secondLargest) {
    *largest = *secondLargest = arr[0];
    
    for ( i = 1; i < n; i++) {
	if (arr[i] > *largest) {
	    *secondLargest = *largest;
	    *largest = arr[i];
	} else if (arr[i] > *secondLargest && arr[i] != *largest) {
	    *secondLargest = arr[i];
	}
    }
}

int main() {
    int n, i;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter the elements:\n");
    for (int i = 0; i < n; i++) {
	scanf("%d", &arr[i]);
    }

    int largest, secondLargest;
    findLargestTwoNumbers(arr, n, &largest, &secondLargest);
    
    printf("The largest two numbers are: %d and %d
", largest, secondLargest);
    
    return 0;
}
