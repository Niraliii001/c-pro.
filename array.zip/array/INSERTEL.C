//inserting array in c
#include<stdio.h>
#include<conio.h>

void main()
{
	int a[100], n, pos, val;
	clrscr();
	printf("\nEnter value to be stored in array: ");
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		printf("\nEnter array value: ");
		scanf("%d",&a[i]);
	}
	printf("\nAdd index to add element: ");
	scanf("%d",&pos);

	printf("\nEnter element to be stored: ");
	scanf("%d",&val);

	for(i=n-1;i>=pos-1;i--)  //50
		a[i+1]=a[i];
	a[pos-1]=val;
	printf("\nAfter adding element\n");
	for(i=0;i<=n;i++)
	{
		printf("%d\n",a[i]);
	}
	getch();
}